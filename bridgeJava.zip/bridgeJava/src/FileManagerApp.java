public class FileManagerApp extends BaseApplication {
    private final String fileToOpen;

    public FileManagerApp(OS_Implementor implementor, String fileToOpen) {
        super(implementor);
        this.fileToOpen = fileToOpen;
    }

    @Override
    public void execute() {
        System.out.println("--- ՖԱՅԼԵՐԻ ԿԱՌԱՎԱՐՈՒՄ ---");
        String result = osImplementor.openFile(fileToOpen);
        System.out.println(result);
    }
}