public interface OS_Implementor {
    String openFile(String fileName);
    String manageMemory();
}