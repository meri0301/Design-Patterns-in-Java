public class WindowsOS implements OS_Implementor{
    @Override
    public String openFile(String fileName) {
        return "Windows API-ի միջոցով բացվում է ֆայլը: " + fileName;
    }

    @Override
    public String manageMemory() {
        return "Windows Kernel-ը կառավարում է հիշողությունը (RAM):";
    }
}
