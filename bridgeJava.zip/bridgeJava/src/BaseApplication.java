public class BaseApplication {
    protected OS_Implementor osImplementor;

    public BaseApplication(OS_Implementor osImplementor) {
        this.osImplementor = osImplementor;
    }

    public void execute() {

    }
}