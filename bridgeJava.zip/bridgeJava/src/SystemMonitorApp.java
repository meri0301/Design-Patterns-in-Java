public class SystemMonitorApp extends BaseApplication {

    public SystemMonitorApp(OS_Implementor implementor) {
        super(implementor);
    }

    @Override
    public void execute() {
        System.out.println("--- ՀԱՄԱԿԱՐԳԱՅԻՆ ՄՈՆԻՏՈՐԻՆԳ ---");
        String result = osImplementor.manageMemory();
        System.out.println(result);
    }
}