public class LinuxOS implements OS_Implementor{
    @Override
    public String openFile(String fileName) {
        return "Linux Syscall-ի միջոցով բացվում է ֆայլը: " + fileName;
    }

    @Override
    public String manageMemory() {
        return "Linux Kernel-ը կառավարում է հիշողությունը (Swap):";
    }
}
