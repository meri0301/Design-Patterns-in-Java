//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
void main() {
    OS_Implementor windows = new WindowsOS();
    OS_Implementor linux = new LinuxOS();

    System.out.println("== ԳՈՐԾԱՐԿՈՒՄԸ WINDOWS-Ի ՎՐԱ ==");

    BaseApplication winFileManager = new FileManagerApp(windows, "report.docx");
    winFileManager.execute();

    BaseApplication winMonitor = new SystemMonitorApp(windows);
    winMonitor.execute();

    System.out.println("\n==================================\n");

    System.out.println("== ԳՈՐԾԱՐԿՈՒՄԸ LINUX-Ի ՎՐԱ ==");

    BaseApplication linuxFileManager = new FileManagerApp(linux, "script.sh");
    linuxFileManager.execute();

    BaseApplication linuxMonitor = new SystemMonitorApp(linux);
    linuxMonitor.execute();
}
