package com.sms.service;

import com.sms.model.Student;
import java.util.List;

public interface StudentService {
    void addStudent(Student student);
    List<Student> getAllStudents();
    void updateStudent(Student student);
    void deleteStudent(int id);

    // Այստեղ կարող են լինել բիզնես մեթոդներ, օրինակ՝ calculateAverageGrade()
}
