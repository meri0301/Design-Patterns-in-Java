package com.sms.service;

import com.sms.dao.StudentDAO;
import com.sms.dao.StudentDAOImpl;
import com.sms.model.Student;
import java.util.List;

public class StudentServiceImpl implements StudentService {

    private final StudentDAO studentDAO;

    public StudentServiceImpl() {
        this.studentDAO = new StudentDAOImpl();
    }

    // C - CREATE
    @Override
    public void addStudent(Student student) {
        // Բիզնես Վալիդացիա
        if (student.getName() == null || student.getName().trim().isEmpty()) {
            throw new IllegalArgumentException("Անունը պարտադիր է։");
        }
        if (student.getAge() < 16 || student.getAge() > 80) {
            throw new IllegalArgumentException("Տարիքը պետք է լինի 16-ից 80 միջակայքում։");
        }

        studentDAO.addStudent(student);
    }

    // R - READ ALL
    @Override
    public List<Student> getAllStudents() {
        return studentDAO.getAllStudents();
    }

    // U - UPDATE
    @Override
    public void updateStudent(Student student) {
        // Կարող է ունենալ նույն վալիդացիան, ինչ addStudent-ը
        studentDAO.updateStudent(student);
    }

    // D - DELETE
    @Override
    public void deleteStudent(int id) {
        studentDAO.deleteStudent(id);
    }
}