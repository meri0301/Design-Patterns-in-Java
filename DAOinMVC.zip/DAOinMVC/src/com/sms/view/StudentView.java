package com.sms.view;

import com.sms.dao.StudentDAO;
import com.sms.dao.StudentDAOImpl;
import com.sms.model.Student;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;

public class StudentView extends JFrame {
    private final StudentDAO studentDAO;

    // GUI Էլեմենտներ
    private final JTable studentTable;
    private final DefaultTableModel tableModel;
    private final JTextField idField;
    private final JTextField nameField;
    private final JTextField ageField;
    private final JTextField gradeField;
    private final JButton addButton;
    private final JButton updateButton;
    private final JButton deleteButton;
    private final JButton clearButton;

    public StudentView() {
        studentDAO = new StudentDAOImpl();
        setTitle("Ուսանողների Կառավարման Համակարգ");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        // 1. Ստեղծել աղյուսակի մոդելը
        String[] columnNames = {"ID", "Անուն", "Տարիք", "Գնահատական"};
        tableModel = new DefaultTableModel(columnNames, 0);
        studentTable = new JTable(tableModel);
        add(new JScrollPane(studentTable), BorderLayout.CENTER);

        // 2. Ստեղծել մուտքագրման պանելը
        JPanel inputPanel = new JPanel(new GridLayout(5, 2));
        idField = new JTextField(5);
        idField.setEditable(false); // ID-ն ավտոմատ է կամ ընտրվում է աղյուսակից
        nameField = new JTextField(15);
        ageField = new JTextField(5);
        gradeField = new JTextField(5);

        inputPanel.add(new JLabel("ID (Select):"));
        inputPanel.add(idField);
        inputPanel.add(new JLabel("Անուն:"));
        inputPanel.add(nameField);
        inputPanel.add(new JLabel("Տարիք:"));
        inputPanel.add(ageField);
        inputPanel.add(new JLabel("Գնահատական:"));
        inputPanel.add(gradeField);

        // 3. Ստեղծել կոճակների պանելը
        JPanel buttonPanel = new JPanel(new FlowLayout());
        addButton = new JButton("Ավելացնել");
        updateButton = new JButton("Թարմացնել");
        deleteButton = new JButton("Ջնջել");
        clearButton = new JButton("Մաքրել Դաշտերը");

        buttonPanel.add(addButton);
        buttonPanel.add(updateButton);
        buttonPanel.add(deleteButton);
        buttonPanel.add(clearButton);

        // 4. Տեղադրել պանելները JFrame-ում
        JPanel southPanel = new JPanel(new BorderLayout());
        southPanel.add(inputPanel, BorderLayout.NORTH);
        southPanel.add(buttonPanel, BorderLayout.SOUTH);
        add(southPanel, BorderLayout.SOUTH);

        // 5. Կոճակների Լսիչները (ActionListener) և DAO Կապը
        setupListeners();

        // 6. Բեռնել սկզբնական տվյալները
        loadStudents();

        pack();
        setLocationRelativeTo(null); // Կենտրոնացնել պատուհանը
    }

    private void setupListeners() {
        // ADD (CREATE)
        addButton.addActionListener(e -> {
            try {
                String name = nameField.getText();
                int age = Integer.parseInt(ageField.getText());
                String grade = gradeField.getText();

                if (!name.isEmpty()) {
                    Student newStudent = new Student(name, age, grade);
                    studentDAO.addStudent(newStudent); // DAO-ի Կանչ
                    loadStudents();
                    clearFields();
                } else {
                    JOptionPane.showMessageDialog(this, "Անունը չի կարող դատարկ լինել։");
                }
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(this, "Խնդրում ենք մուտքագրել վավեր տարիք։");
            }
        });

        // UPDATE (UPDATE)
        updateButton.addActionListener(e -> {
            try {
                int id = Integer.parseInt(idField.getText());
                String name = nameField.getText();
                int age = Integer.parseInt(ageField.getText());
                String grade = gradeField.getText();

                if (id != 0 && !name.isEmpty()) {
                    Student studentToUpdate = new Student(id, name, age, grade);
                    studentDAO.updateStudent(studentToUpdate); // DAO-ի Կանչ
                    loadStudents();
                    clearFields();
                } else {
                    JOptionPane.showMessageDialog(this, "Ընտրեք ուսանողին կամ լրացրեք բոլոր դաշտերը։");
                }
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(this, "ID և Տարիք դաշտերը պետք է լինեն թվեր։");
            }
        });

        // DELETE (DELETE)
        deleteButton.addActionListener(e -> {
            try {
                int id = Integer.parseInt(idField.getText());
                if (id != 0) {
                    studentDAO.deleteStudent(id); // DAO-ի Կանչ
                    loadStudents();
                    clearFields();
                } else {
                    JOptionPane.showMessageDialog(this, "Ընտրեք ուսանողին ջնջելու համար։");
                }
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(this, "Խնդրում ենք ընտրել վավեր ID։");
            }
        });

        // CLEAR FIELDS
        clearButton.addActionListener(e -> clearFields());

        // Ընտրելիս դաշտերը լրացնելու համար
        studentTable.getSelectionModel().addListSelectionListener(e -> {
            int selectedRow = studentTable.getSelectedRow();
            if (selectedRow != -1) {
                idField.setText(tableModel.getValueAt(selectedRow, 0).toString());
                nameField.setText(tableModel.getValueAt(selectedRow, 1).toString());
                ageField.setText(tableModel.getValueAt(selectedRow, 2).toString());
                gradeField.setText(tableModel.getValueAt(selectedRow, 3).toString());
            }
        });
    }

    // R - READ (Ցուցակը թարմացնելու մեթոդ)
    private void loadStudents() {
        tableModel.setRowCount(0); // Մաքրել հին տվյալները
        List<Student> students = studentDAO.getAllStudents(); // DAO-ի Կանչ
        for (Student s : students) {
            tableModel.addRow(new Object[]{s.getId(), s.getName(), s.getAge(), s.getGrade()});
        }
    }

    private void clearFields() {
        idField.setText("");
        nameField.setText("");
        ageField.setText("");
        gradeField.setText("");
    }
}