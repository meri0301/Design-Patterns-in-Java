import com.sms.view.StudentView;
import javax.swing.SwingUtilities;

void main() {
    SwingUtilities.invokeLater(() -> {
        new StudentView().setVisible(true);
    });
}
