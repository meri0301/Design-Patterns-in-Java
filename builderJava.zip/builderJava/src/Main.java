//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
void main() {
    User basicUser = new User.Builder("Աննա", "Գրիգորյան")
            .build();

    System.out.println("Basic User:");
    System.out.println(basicUser);

    System.out.println("---");

    User fullUser = new User.Builder("Դավիթ", "Մարգարյան")
            .age(35)
            .phone("099-555-444")
            .address("Երևան, Կոմիտասի 25")
            .build();

    System.out.println("Full User:");
    System.out.println(fullUser);

    System.out.println("---");

    User partialUser = new User.Builder("Նարինե", "Պետրոսյան")
            .age(28)
            .build();

    System.out.println("Partial User:");
    System.out.println(partialUser);
}
