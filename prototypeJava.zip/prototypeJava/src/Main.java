import com.example.prototype.Mail;
import com.example.prototype.MailGenerator;

void main() {

    String subject = "Կարևոր ծանուցում Մերիից :)";
    String body = "Հարգելի {NAME},\n\nՁեզ է ուղղվում այս նամակը՝ տեղեկացնելու համար Ձեր ուսման գծով նորությունների մասին։\n\nՇնորհակալություն,\nՄերի";

    MailGenerator generator = new MailGenerator(subject, body);

    Mail mail2 = generator.createPersonalizedMail("Meri Movsesyan");
    if (mail2 != null) {
        mail2.send();
    }

}
