package com.example.prototype;

import jakarta.mail.*;
import jakarta.mail.internet.*;
import jakarta.mail.Message;
import java.util.Properties;

public class Mail implements CloneableMail {

    private String receiverName;
    private String receiverEmail;
    private final String subject;
    private final String bodyTemplate;

    private static final String SMTP_HOST = "smtp.gmail.com";
    private static final String SMTP_PORT = "465"; // or 465, or 587
    private static final String SENDER_EMAIL = "meri.movsesyan0301@gmail.com";
    private static final String SENDER_PASSWORD = "xcgo bqry kpsi umf";

    // Կոնստրուկտոր՝ նախնական տեքստը սահմանելու համար
    public Mail(String subject, String bodyTemplate) {
        this.subject = subject;
        this.bodyTemplate = bodyTemplate;
    }

    @Override
    public CloneableMail cloneMail() {
        try {
            return (Mail) super.clone();
        } catch (CloneNotSupportedException e) {
            throw new InternalError("Cloning not supported for Mail object", e);
        }
    }

    public void personalize(String name, String email) {
        this.receiverName = name;
        this.receiverEmail = email;
    }

    @Override
    public void send() {
        String personalizedBody = bodyTemplate.replace("{NAME}", receiverName);

        Properties properties = new Properties();
//        properties.put("mail.smtp.host", SMTP_HOST);
//        properties.put("mail.smtp.port", SMTP_PORT);
//        properties.put("mail.smtp.auth", "true");
//        properties.put("mail.smtp.starttls.enable", "true");

        properties.put("mail.smtp.host", SMTP_HOST); // smtp.gmail.com
        properties.put("mail.smtp.socketFactory.port", SMTP_PORT); // 465
        properties.put("mail.smtp.ssl.enable", "true");
        properties.put("mail.smtp.auth", "true");
        properties.put("mail.transport.protocol", "smtps");

        Session session = Session.getInstance(properties, new Authenticator() {
            @Override
            protected PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication(SENDER_EMAIL, SENDER_PASSWORD);
            }
        });


        try {
            Message message = new MimeMessage(session);
            message.setFrom(new InternetAddress(SENDER_EMAIL));
            message.setRecipients(
                    Message.RecipientType.TO,
                    InternetAddress.parse(receiverEmail)
            );
            message.setSubject(subject);
            message.setText(personalizedBody);

            Transport.send(message);
//            message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(receiverEmail));
            System.out.println("✅ Նամակն ԻՐԱԿԱՆՈՒՄ ուղարկվեց " + receiverName + " <" + receiverEmail + "> հասցեին:");

        } catch (MessagingException e) {
            System.err.println("❌ Սխալ նամակն ուղարկելիս " + receiverEmail + ": " + e.getMessage());
        }
    }
}
