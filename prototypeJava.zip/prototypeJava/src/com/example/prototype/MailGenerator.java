package com.example.prototype;

import java.util.HashMap;
import java.util.Map;

public class MailGenerator {

    private final Mail defaultMailPrototype;
    private final Map<String, String> emailAddressBook = new HashMap<>();

    public MailGenerator(String defaultSubject, String defaultBodyTemplate) {

        this.defaultMailPrototype = new Mail(defaultSubject, defaultBodyTemplate);

        emailAddressBook.put("Meri Movsesyan", "meri.movsesyan0301@gmail.com");
        emailAddressBook.put("Grigor Petrosyan", "grigor.petrosyan@nuaca.am");
        emailAddressBook.put("Mariam Karapetyan", "m.karapetyan@gmail.com");
        emailAddressBook.put("Gor Aleksanyan", "g.aleksanyan1998@gmail.com");
    }

    private String generateNuacaEmail(String fullName) {
        if (fullName == null || fullName.trim().isEmpty()) {
            return null;
        }

        // 1. Սարքել փոքրատառ
        String normalized = fullName.toLowerCase();

        // 2. Բացատները փոխարինել կետերով
        String emailPart = normalized.replace(" ", ".");

        // 3. Ավելացնել դոմեյնը
        return emailPart + "@nuaca.am";
    }

    public Mail createPersonalizedMail(String fullName) {

        String email = emailAddressBook.get(fullName);

        boolean generated = false;

        if (email == null) {
            // 2. Եթե Map-ում չկա, գեներացնում ենք NUACA լոգիկայով
            email = generateNuacaEmail(fullName);
            generated = true;
        }

        if (email == null) {
            System.err.println("❌ Սխալ: Հնարավոր չէ գտնել/գեներացնել էլ. փոստի հասցեն՝ " + fullName + "-ի համար:");
            return null;
        }

        Mail newMail = (Mail) defaultMailPrototype.cloneMail();

        newMail.personalize(fullName, email);

        if (generated) {
            System.out.println("ℹ️ Նամակի հասցեն գեներացվել է NUACA լոգիկայով։");
        }

        return newMail;
    }
}