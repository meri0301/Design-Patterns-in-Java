package com.example.prototype;

public interface CloneableMail extends  Cloneable {
    CloneableMail cloneMail();

    void send();
}
