package com.sms.model;

public class Student {
    private int id;
    private String name;
    private int age;
    private String grade;

    // Կոնստրուկտոր՝ նոր ուսանող ավելացնելու համար (առանց id-ի, քանի որ AI է)
    public Student(String name, int age, String grade) {
        this.name = name;
        this.age = age;
        this.grade = grade;
    }

    // Կոնստրուկտոր՝ DB-ից վերցված ուսանողի համար (id-ով)
    public Student(int id, String name, int age, String grade) {
        this.id = id;
        this.name = name;
        this.age = age;
        this.grade = grade;
    }

    // Getters and Setters
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public int getAge() { return age; }
    public void setAge(int age) { this.age = age; }
    public String getGrade() { return grade; }
    public void setGrade(String grade) { this.grade = grade; }

    @Override
    public String toString() {
        return "Student [id=" + id + ", name=" + name + ", age=" + age + ", grade=" + grade + "]";
    }
}