package com.sms.dao;

import com.sms.model.Student;
import java.util.List;

public interface StudentDAO {
    // C - Create
    void addStudent(Student student);

    // R - Read
    Student getStudentById(int id);
    List<Student> getAllStudents();

    // U - Update
    void updateStudent(Student student);

    // D - Delete
    void deleteStudent(int id);
}