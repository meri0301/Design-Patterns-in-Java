package com.sms.db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBConnection {
    // Փոխարինեք Ձեր տվյալներով
    private static final String URL = "jdbc:mysql://localhost:3306/my_schema";
    private static final String USER = "root"; // Ձեր MySQL օգտատիրոջ անունը
    private static final String PASSWORD = "Goodok4242+"; // Ձեր գաղտնաբառը

    public static Connection getConnection() throws SQLException {
        try {
            // Բեռնում ենք JDBC դրայվերը
            Class.forName("com.mysql.cj.jdbc.Driver");
            return DriverManager.getConnection(URL, USER, PASSWORD);
        } catch (ClassNotFoundException e) {
            System.err.println("MySQL JDBC Driver-ը չգտնվեց։");
            e.printStackTrace();
            throw new SQLException("DB Driver Խնդիր");
        }
    }
}