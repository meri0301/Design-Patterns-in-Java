import com.sms.view.StudentView;

import javax.swing.SwingUtilities;//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
void main() {
    SwingUtilities.invokeLater(() -> {
        new StudentView().setVisible(true);
    });
}
